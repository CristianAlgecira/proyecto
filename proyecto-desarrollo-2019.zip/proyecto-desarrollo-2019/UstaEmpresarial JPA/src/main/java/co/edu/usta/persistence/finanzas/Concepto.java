package co.edu.usta.persistence.finanzas;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "concepto", schema = "finanzas")
public class Concepto implements Serializable {

    @Id
    @GeneratedValue
    @Column(name = "codigo", nullable = false)
    private int codigo;

    @Column(name = "nombre", nullable = false, length = 20)
    private String nombre;

    @Column(name = "descrpcion", nullable = true, length = 100)
    private String descripcion;

    @Column(name = "tipo", nullable = false)
    private boolean tipo;

    @Column(name = "estado", nullable = false)
    private boolean estado;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "plan_contable_codigo", nullable = false)
    private PlanContable planContable;

    public Concepto() {



    }

    public Concepto(String nombre, String descripcion, boolean tipo, boolean estado, PlanContable planContable) {

        this.nombre = nombre;
        this.descripcion = descripcion;
        this.tipo = tipo;
        this.estado = estado;
        this.planContable = planContable;

    }

    public int getCodigo() {

        return codigo;

    }

    public void setCodigo(int codigo) {

        this.codigo = codigo;

    }

    public String getNombre() {

        return nombre;

    }

    public void setNombre(String nombre) {

        this.nombre = nombre;

    }

    public String getDescripcion() {

        return descripcion;

    }

    public void setDescripcion(String descripcion) {

        this.descripcion = descripcion;

    }

    public boolean isTipo() {

        return tipo;

    }

    public void setTipo(boolean tipo) {

        this.tipo = tipo;

    }

    public boolean isEstado() {

        return estado;

    }

    public void setEstado(boolean estado) {

        this.estado = estado;

    }

    public PlanContable getPlanContable() {

        return planContable;

    }

    public void setPlanContable(PlanContable planContable) {

        this.planContable = planContable;

    }

}
