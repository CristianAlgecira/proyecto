package co.edu.usta.persistence.crm;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "periodo", schema = "crm")
@NoArgsConstructor
@AllArgsConstructor
@NamedQuery(name="Periodo.findAll", query="SELECT p FROM Periodo p")
public class Periodo implements Serializable {

    public static final String LISTAR_PERIODO = "Periodo.findAll";

    @Id
    @GeneratedValue
    @Column(name = "codigo", nullable = false)
    private @Getter @Setter
    int codigo;

    @Column(name = "fecha_inicio", nullable = false)
    private @Getter @Setter
    Date fechaInicio;

    @Column(name = "fecha_fin", nullable = false)
    private @Getter @Setter
    Date fechaFin;

    @Column(name = "estado", nullable = false)
    private @Getter @Setter
    boolean estado;

    public Periodo(int codigo) {

        this.codigo = codigo;

    }

}
